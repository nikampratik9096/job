import React, { useState } from 'react';
import { FileText, Clock, CheckCircle, XCircle } from 'lucide-react';
import type { Application } from '../types';

export default function Dashboard() {
  const [applications] = useState<Application[]>([
    {
      id: '1',
      jobId: '1',
      name: 'John Doe',
      email: 'john@example.com',
      phone: '123-456-7890',
      status: 'reviewing',
      resumeUrl: '#',
      appliedDate: '2024-03-15'
    },
    {
      id: '2',
      jobId: '2',
      name: 'Jane Smith',
      email: 'jane@example.com',
      phone: '123-456-7891',
      status: 'accepted',
      resumeUrl: '#',
      appliedDate: '2024-03-14'
    },
    {
      id: '3',
      jobId: '3',
      name: 'Bob Johnson',
      email: 'bob@example.com',
      phone: '123-456-7892',
      status: 'pending',
      resumeUrl: '#',
      appliedDate: '2024-03-13'
    }
  ]);

  const getStatusColor = (status: Application['status']) => {
    switch (status) {
      case 'pending':
        return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200';
      case 'reviewing':
        return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200';
      case 'accepted':
        return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200';
      case 'rejected':
        return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200';
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200';
    }
  };

  const getStatusIcon = (status: Application['status']) => {
    switch (status) {
      case 'pending':
        return <Clock size={16} />;
      case 'reviewing':
        return <FileText size={16} />;
      case 'accepted':
        return <CheckCircle size={16} />;
      case 'rejected':
        return <XCircle size={16} />;
      default:
        return null;
    }
  };

  return (
    <div className="space-y-8">
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
          Your Applications
        </h1>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {['All', 'Pending', 'Reviewing', 'Accepted'].map((filter) => (
            <button
              key={filter}
              className="btn-secondary"
            >
              {filter}
            </button>
          ))}
        </div>
      </div>

      <div className="space-y-4">
        {applications.map((application) => (
          <div
            key={application.id}
            className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6 hover:shadow-md transition-shadow duration-200"
          >
            <div className="flex flex-col md:flex-row md:items-center md:justify-between">
              <div className="space-y-2">
                <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
                  {application.name}
                </h2>
                <div className="flex items-center space-x-4 text-gray-600 dark:text-gray-300">
                  <span>{application.email}</span>
                  <span>{application.phone}</span>
                </div>
              </div>
              <div className="mt-4 md:mt-0 flex items-center space-x-4">
                <span
                  className={`inline-flex items-center px-3 py-1 rounded-full text-sm ${getStatusColor(
                    application.status
                  )}`}
                >
                  <span className="mr-2">{getStatusIcon(application.status)}</span>
                  {application.status.charAt(0).toUpperCase() + application.status.slice(1)}
                </span>
                <button className="btn-secondary">
                  View Details
                </button>
              </div>
            </div>
            <div className="mt-4 text-sm text-gray-600 dark:text-gray-300">
              Applied on {new Date(application.appliedDate).toLocaleDateString()}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}