import React, { useState } from 'react';
import { Search, MapPin, Clock, Briefcase } from 'lucide-react';
import type { Job } from '../types';

export default function Jobs() {
  const [searchTerm, setSearchTerm] = useState('');
  const [locationFilter, setLocationFilter] = useState('');

  const jobs: Job[] = [
    {
      id: '1',
      title: 'Senior Frontend Developer',
      company: 'TechCorp',
      location: 'San Francisco, CA',
      type: 'Full-time',
      description: 'We are looking for an experienced Frontend Developer to join our team.',
      requirements: ['5+ years React experience', 'TypeScript proficiency', 'Team leadership'],
      postedDate: '2024-03-15'
    },
    {
      id: '2',
      title: 'Backend Engineer',
      company: 'DataSys',
      location: 'Remote',
      type: 'Full-time',
      description: 'Join our backend team to build scalable systems.',
      requirements: ['Node.js', 'PostgreSQL', 'AWS'],
      postedDate: '2024-03-14'
    },
    {
      id: '3',
      title: 'UI/UX Designer',
      company: 'CreativeStudio',
      location: 'New York, NY',
      type: 'Contract',
      description: 'Design beautiful and intuitive user interfaces for our products.',
      requirements: ['Figma', 'User Research', 'Prototyping'],
      postedDate: '2024-03-13'
    }
  ];

  const filteredJobs = jobs.filter(job => {
    const matchesSearch = job.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         job.company.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesLocation = !locationFilter || job.location.toLowerCase().includes(locationFilter.toLowerCase());
    return matchesSearch && matchesLocation;
  });

  return (
    <div className="space-y-8">
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
            <input
              type="text"
              placeholder="Search jobs by title or company"
              className="input-field pl-10"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <div className="relative">
            <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
            <input
              type="text"
              placeholder="Filter by location"
              className="input-field pl-10"
              value={locationFilter}
              onChange={(e) => setLocationFilter(e.target.value)}
            />
          </div>
        </div>
      </div>

      <div className="space-y-4">
        {filteredJobs.map((job) => (
          <div key={job.id} className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6 hover:shadow-md transition-shadow duration-200">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between">
              <div className="space-y-2">
                <h2 className="text-xl font-semibold text-gray-900 dark:text-white">{job.title}</h2>
                <div className="flex items-center space-x-4 text-gray-600 dark:text-gray-300">
                  <span className="flex items-center">
                    <Briefcase size={16} className="mr-1" />
                    {job.company}
                  </span>
                  <span className="flex items-center">
                    <MapPin size={16} className="mr-1" />
                    {job.location}
                  </span>
                  <span className="flex items-center">
                    <Clock size={16} className="mr-1" />
                    {new Date(job.postedDate).toLocaleDateString()}
                  </span>
                </div>
              </div>
              <div className="mt-4 md:mt-0">
                <button className="btn-primary">Apply Now</button>
              </div>
            </div>
            <div className="mt-4">
              <p className="text-gray-600 dark:text-gray-300">{job.description}</p>
              <div className="mt-4 flex flex-wrap gap-2">
                {job.requirements.map((req, index) => (
                  <span
                    key={index}
                    className="px-3 py-1 bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200 rounded-full text-sm"
                  >
                    {req}
                  </span>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}